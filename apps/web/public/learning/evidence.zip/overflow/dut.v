// Countertrace fixture: known-good synchronous FIFO, pointer + occupancy-count style.
// Authored for Countertrace (MIT). Supported profile: sync-fifo-v1, WIDTH 8, DEPTH 2 or 4.
`default_nettype none
module fifo #(
    parameter integer DEPTH = 4,
    parameter integer WIDTH = 8
) (
    input  wire             clk,
    input  wire             rst,
    input  wire             wr_en,
    input  wire             rd_en,
    input  wire [WIDTH-1:0] din,
    output reg  [WIDTH-1:0] dout,
    output wire             full,
    output wire             empty
);
    localparam integer AW = $clog2(DEPTH);

    reg [WIDTH-1:0] mem [0:DEPTH-1];
    reg [AW-1:0]    wr_ptr;
    reg [AW-1:0]    rd_ptr;
    reg [AW:0]      count;

    wire do_read  = rd_en && (count != 0);
    wire do_write = wr_en;

    assign empty = (count == 0);
    assign full  = (count == DEPTH);

    always @(posedge clk) begin
        if (rst) begin
            wr_ptr <= 0;
            rd_ptr <= 0;
            count  <= 0;
        end else begin
            if (do_write) begin
                mem[wr_ptr] <= din;
                wr_ptr      <= wr_ptr + 1'b1;
            end
            if (do_read) begin
                dout   <= mem[rd_ptr];
                rd_ptr <= rd_ptr + 1'b1;
            end
            case ({do_write, do_read})
                2'b10:   count <= (count == DEPTH) ? count : count + 1'b1;
                2'b01:   count <= count - 1'b1;
                default: count <= count;
            endcase
        end
    end
endmodule
`default_nettype wire
